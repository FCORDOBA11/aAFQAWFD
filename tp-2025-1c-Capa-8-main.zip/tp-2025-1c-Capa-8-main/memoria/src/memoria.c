#include "memoria.h"
#include "utils/hello.h"
#include <stdio.h>
#include <stdlib.h>

int PUERTO_MEMORIA = 0;

t_log* inicializar_log(void) {
  t_log* memoria_log = log_create("memoria.log", "MEMORIA", true, LOG_LEVEL_INFO); // Crea .log
  if (memoria_log == NULL) {
    perror("ERROR - NO HAY LOGGER"); //Mensaje de error
    exit(EXIT_FAILURE);  // corta el programa
  }

  return memoria_log;
}

t_config* inicializar_config(void) {
  t_config* memoria_config = config_create("memoria.config");

  if (memoria_config == NULL) {
    perror("ERROR - NO HAY CONFIG");
    exit(EXIT_FAILURE);  // corta el programa
  }
  
  PUERTO_MEMORIA = config_get_int_value(memoria_config, "PUERTO_MEMORIA");
  // TAM_MEMORIA = config_get_int_value(memoria_config, "TAM_MEMORIA");
  // TAM_PAGINA = config_get_int_value(memoria_config, "TAM_PAGINA");
  // ENTRADAS_POR_TABLA = config_get_int_value(memoria_config, "ENTRADAS_POR_TABLA");
  // CANTIDAD_NIVELES = config_get_int_value(memoria_config, "CANTIDAD_NIVELES");
  // RETARDO_MEMORIA = config_get_int_value(memoria_config, "RETARDO_MEMORIA");
  // PATH_SWAPFILE = config_get_string_value(memoria_config, "PATH_SWAPFILE");
  // RETARDO_SWAP = config_get_int_value(memoria_config, "RETARDO_SWAP");
  // LOG_LEVEL = config_get_string_value(memoria_config, "LOG_LEVEL");
  // DUMP_PATH = config_get_string_value(memoria_config, "DUMP_PATH");
  // PATH_INSTRUCCIONES = config_get_string_value(memoria_config, "PATH_INSTRUCCIONES");

  return memoria_config;
}

argumentos_servidor_memoria* cargar_argumentos(t_log* logger, int puerto){
  argumentos_servidor_memoria* argumentos = malloc(sizeof(argumentos_servidor_memoria));
  argumentos->logger = logger;
  argumentos->puerto = puerto;

  return argumentos;
}

void* atender_cliente(void* arg){
  argumentos_servidor_memoria* data = (argumentos_servidor_memoria*) arg;
  int socket_server_memoria = iniciar_servidor(data->logger, data->puerto);
  if (socket_server_memoria == -1) {
    log_error(data->logger, "Error: fallo al iniciar servidor en puerto %d.", data->puerto);
    return NULL;
  }

  log_info(data->logger, "Servidor iniciado correctamente en puerto %d, esperando conexiones...", data->puerto);

  while (1) {
    struct sockaddr_in cliente_addr;
    socklen_t addr_len = sizeof(cliente_addr);
    int cliente_socket = accept(socket_server_memoria, (struct sockaddr*)&cliente_addr, &addr_len);
    if (cliente_socket == -1) {
      log_error(data->logger, "Error en accept()");
      continue;
    }

    log_info(data->logger, "Nueva conexión aceptada");

    // Aquí podés crear un hilo para atender la conexión o atenderla directamente.
    // Ejemplo directo (sin hilos):

    // atender_peticion(cliente_socket, data->logger);

    // Luego cerrás la conexión
    close(cliente_socket);
  }

  close(socket_server_memoria);
  return NULL;
}

